# units-system.js

The purpose of this task is to work on the provided unit system implementation in two areas:
- Unit tests (add) - units.test.js file
- Unit system implementation (bug fixing, extending) - units.js file
  
## Tasks: ##
- Add unit tests to achieve the highest coverage (run `npm run test:coverage`)
- Fix bugs
- Add new units for length: inch, foot. Remember about the coverage.
- Add an optional power parameter to methods, e.g., 2m^2 (with appropriate tests). Remember about the coverage.
- Implement `calculate`:
  - Input: '1m + 2mm', "millimeter"
  - Output: 1002
  - Assumptions: Only basic operations (+, -), no brackets, validate if the unit is in the same group

As a result of your work, we expect the units.js and units.test.js files to be provided.

## Requirements: ##

- nodejs with npm (version 16 or newer) (https://nodejs.org/en/)

## Installation: ##

- `npm install`

## Running: ##

- `npm run test`
- `npm run test:coverage`
