const Units = require('./units');

let unitsSystem;

beforeEach(() => {
  unitsSystem = new Units();
});

describe("Units System", () => {
  test("Convert length correctly", () => {
    expect(unitsSystem.convert(1, 'm', 'cm')).toBe(100);
    expect(unitsSystem.convert(100, 'cm', 'm')).toBe(1);
    expect(unitsSystem.convert(1, 'in', 'cm')).toBeCloseTo(2.54);
    expect(unitsSystem.convert(1, 'ft', 'm')).toBeCloseTo(0.3048);
  });

  test("Convert mass correctly", () => {
    expect(unitsSystem.convert(1, 'kg', 'g')).toBe(1000);
    expect(unitsSystem.convert(1, 't', 'kg')).toBe(1000);
  });

  test("Throw error when converting different groups", () => {
    expect(() => unitsSystem.convert(1, 'm', 'g')).toThrow("not the same group");
  });

  test("Format conversion result correctly", () => {
    expect(unitsSystem.format(1, 'm', 'cm')).toBe("100 cm");
    expect(unitsSystem.format(1, 'kg', 'g')).toBe("1000 g");
  });

  test("Get available units by group", () => {
    expect(unitsSystem.getUnits('length')).toEqual(["meter", "centimeter", "millimeter", "inch", "foot"]);
    expect(unitsSystem.getUnits('mass')).toEqual(["gram", "kilogram", "ton"]);
  });

  test("Get all unit groups", () => {
    expect(unitsSystem.getGroups()).toEqual(["length", "mass"]);
  });

  test("Handle power parameter in conversion", () => {
    expect(unitsSystem.convert(2, 'm', 'cm', 2)).toBe(400);
    expect(unitsSystem.convert(3, 'ft', 'in', 2)).toBeCloseTo(1296);
  });
  
  test("Calculate simple expressions", () => {
    expect(unitsSystem.calculate("1m + 2mm", "mm")).toBe(1002);
    expect(unitsSystem.calculate("5ft - 6in", "inch")).toBeCloseTo(54);
  });

  test("Throw error for invalid units in calculate", () => {
    expect(() => unitsSystem.calculate("1m + 2g", "m")).toThrow("Invalid or mismatched units");
  });
});
