class Units {
  constructor() {
    this._units = {};
    this.initializeUnits();
  }

  addUnit(unit) {
    this._units[unit.symbol] = unit;
  }

  initializeUnits() {
    // Length
    this.addUnit(new Unit('meter', 'm', 1, 'length'));
    this.addUnit(new Unit('centimeter', 'cm', 0.01, 'length'));
    this.addUnit(new Unit('millimeter', 'mm', 0.001, 'length'));
    this.addUnit(new Unit('inch', 'in', 0.0254, 'length'));
    this.addUnit(new Unit('foot', 'ft', 0.3048, 'length'));
  
    // Mass
    this.addUnit(new Unit('gram', 'g', 0.001, 'mass'));
    this.addUnit(new Unit('kilogram', 'kg', 1, 'mass'));
    this.addUnit(new Unit('ton', 't', 1000, 'mass'));
  }
  
  convert(value, inputUnit, outputUnit, power = 1) {
    const from = this._units[inputUnit];
    const to = this._units[outputUnit];
  
    if (!from || !to) {
      throw new Error(`Invalid unit: ${inputUnit} or ${outputUnit}`);
    }
    if (from.group !== to.group) {
      throw new Error("not the same group");
    }
  
    const baseConversion = (value * Math.pow(from.toBaseCoeff, power)) / Math.pow(to.toBaseCoeff, power);
  
    return baseConversion;
  }  
  
  format(value, inputUnit, outputUnit, power = 1) {
    return `${this.convert(value, inputUnit, outputUnit, power)} ${this._units[outputUnit].symbol}`;
  }

  getUnits(group) {
    return Object.values(this._units)
      .filter((unit) => unit.group === group)
      .map((unit) => unit.name);
  }

  getGroups() {
    return [...new Set(Object.values(this._units).map((unit) => unit.group))];
  }

  calculate(expression, outputUnit) {
    if (!this._units[outputUnit]) {
      throw new Error('Invalid output unit');
    }
  
    const regex = /(-?\d+(?:\.\d+)?)([a-zA-Z]+)/g;
    let match;
    let sum = 0;
    while ((match = regex.exec(expression)) !== null) {
      const value = parseFloat(match[1]);
      const unit = match[2];
  
      if (!this._units[unit] || this._units[unit].group !== this._units[outputUnit].group) {
        throw new Error('Invalid or mismatched units');
      }
  
      sum += this.convert(value, unit, outputUnit);
    }
    return sum;
  }
}

class Unit {
  constructor(name, symbol, toBaseCoeff, group) {
    this._name = name;
    this._symbol = symbol;
    this._toBaseCoeff = toBaseCoeff;
    this._group = group;
  }

  get name() {
    return this._name;
  }

  get symbol() {
    return this._symbol;
  }

  get toBaseCoeff() {
    return this._toBaseCoeff;
  }

  get group() {
    return this._group;
  }
}

module.exports = Units;
